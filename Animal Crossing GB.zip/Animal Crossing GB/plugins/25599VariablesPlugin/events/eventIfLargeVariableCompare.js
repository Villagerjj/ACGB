export const id = "IF_LARGE_VARIABLE_COMPARE";
export const name = "If Large Variable Compare With Value";
export const fields = [
    {
      key: "vectorX",
      type: "variable",
      defaultValue: "LAST_VARIABLE",
      width: "50%"
    },
    {
      key: "vectorZ",
      type: "variable",
      defaultValue: "LAST_VARIABLE",
      width: "50%"
    },
    {
      key: "operator",
      type: "operator",
      width: "50%",
      defaultValue: "=="
    },
    {
      key: "other",
      type: "select",
      options: [
        ["var", "Normal Variable"],
        ["lgv", "Large Variable"],
        ["val", "Value"]
      ],
      defaultValue: "val",
      width: "50%"
    },
    {
      key: "vectorY",
      type: "variable",
      conditions: [
        {
          key: "other",
          eq: "var"
        }
      ],
      defaultValue: "LAST_VARIABLE"
    },
    {
      key: "vectorA",
      type: "variable",
      conditions: [
        {
          key: "other",
          eq: "lgv"
        }
      ],
      defaultValue: "LAST_VARIABLE",
      width: "50%"
    },
    {
      key: "vectorB",
      type: "variable",
      conditions: [
        {
          key: "other",
          eq: "lgv"
        }
      ],
      defaultValue: "LAST_VARIABLE",
      width: "50%"
    },
    {
      key: "val",
      type: "number",
      conditions: [
        {
          key: "other",
          eq: "val"
        }
      ],
      min: 0,
      max: 25599,
      defaultValue: "0"
    },
    {
      key: "true",
      type: "events"
    },
    {
      key: "__collapseElse",
      label: "Else",
      type: "collapsable",
      defaultValue: false,
      conditions: [
        {
          key: "__disableElse",
          ne: true
        }
      ]
    },
    {
      key: "false",
      conditions: [
        {
          key: "__collapseElse",
          ne: true
        },
        {
          key: "__disableElse",
          ne: true
        }
      ],
      type: "events"
    }
];
  
export const compile = (input, helpers) => {
    const { ifVariableCompare, variableSetToValue, variableCopy, variableFromUnion, temporaryEntityVariable } = helpers;
    const truePath = input.true;
    const falsePath = input.__disableElse ? [] : input.false;

    const hiVariable2 = "hi";
    const loVariable2 = "lo";
    switch (input.other) {
      case "val":
        variableSetToValue(hiVariable2, Math.floor(input.val / 100));
        variableSetToValue(loVariable2, input.val % 100);
        break;
      case "var":
        variableSetToValue(hiVariable2, 0);
        variableCopy(loVariable2, input.vectorY);
        break;
      case "lgv":
        variableCopy(hiVariable2, input.vectorA);
        variableCopy(loVariable2, input.vectorB);
        break;
    }
    switch (input.operator) {
      case "==":
        ifVariableCompare(
            input.vectorX,
            "==",
            hiVariable2,
            ()=>{ifVariableCompare(input.vectorZ, "==", loVariable2, truePath, falsePath)},
            falsePath
        );
        break;
      case "!=":
        ifVariableCompare(
            input.vectorX,
            "==",
            hiVariable2,
            ()=>{ifVariableCompare(input.vectorZ, "==", loVariable2, falsePath, truePath)},
            truePath
        );
        break;
      case "<":
      case ">":
        ifVariableCompare(
            input.vectorX,
            input.operator,
            hiVariable2,
            truePath,
            ()=>{
                ifVariableCompare(
                    input.vectorX,
                    "==",
                    hiVariable2,
                    ()=>{ifVariableCompare(input.vectorZ, input.operator, loVariable2, truePath, falsePath)},
                    falsePath
                );
            },
        );
        break;
      default:
        ifVariableCompare(
            input.vectorX,
            input.operator[0],
            hiVariable2,
            truePath,
            ()=>{
                ifVariableCompare(
                    input.vectorX,
                    "==",
                    hiVariable2,
                    ()=>{ifVariableCompare(input.vectorZ, input.operator, loVariable2, truePath, falsePath)},
                    falsePath
                );
            },
        );
        break;
    }
};