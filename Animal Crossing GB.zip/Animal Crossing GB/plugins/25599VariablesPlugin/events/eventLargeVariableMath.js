export const id = "LARGE_VARIABLE_MATH";
export const name = "Large Variable: Math Functions";
export const fields = [
  {
    key: "vectorX",
    type: "variable",
    defaultValue: "LAST_VARIABLE",
    width: "50%"
  },
  {
    key: "vectorY",
    type: "variable",
    defaultValue: "LAST_VARIABLE",
    width: "50%"
  },
  {
    key: "operation",
    type: "select",
    options: [
      ["set", "Set To"],
      ["add", "Add"],
      ["sub", "Subtract"]
    ],
    defaultValue: "set",
    width: "50%"
  },
  {
    key: "other",
    type: "select",
    options: [
      ["var", "Normal Variable"],
      ["lgv", "Large Variable"],
      ["val", "Value"]
    ],
    defaultValue: "val",
    width: "50%"
  },
  {
    key: "vectorZ",
    type: "variable",
    conditions: [
      {
        key: "other",
        eq: "var"
      }
    ],
    defaultValue: "LAST_VARIABLE",
  },
  {
    key: "value",
    type: "number",
    conditions: [
      {
        key: "other",
        eq: "val"
      }
    ],
    min: 0,
    max: 25599,
    defaultValue: "0"
  },
  {
    key: "vectorA",
    type: "variable",
    conditions: [
      {
        key: "other",
        eq: "lgv"
      }
    ],
    defaultValue: "LAST_VARIABLE",
    width: "50%"
  },
  {
    key: "vectorB",
    type: "variable",
    conditions: [
      {
        key: "other",
        eq: "lgv"
      }
    ],
    defaultValue: "LAST_VARIABLE",
    width: "50%"
  },
  {
    label: "Note: Value is automatically clamped between 0 and 25599.",
    conditions: [
      {
        key: "operation",
        ne: "set"
      }
    ],
  }
];

export const compile = (input, helpers) => {
  const {
    variableSetToValue,
    variableCopy,
    variablesAdd,
    variablesSub,
    ifVariableCompare
  } = helpers;
  const tmp1 = "tmp1";
  const tmp2 = "tmp2";
  switch (input.other) {
    case "var":
      variableSetToValue(tmp1, 0);
      variableCopy(tmp2, input.vectorZ);
      break;
    case "lgv":
      variableCopy(tmp1, input.vectorA);
      variableCopy(tmp2, input.vectorB);
      break;
    case "val":
    default:
      variableSetToValue(tmp1, Math.floor((input.value || 0) / 100));
      variableSetToValue(tmp2, (input.value || 0) % 100);
      break;
  }
  const tmp6 = "tmp6";
  const tmp7 = "tmp7";
  const tmp8 = "tmp8";
  switch (input.operation) {
    case "add":
      variableCopy(tmp7, input.vectorX);
      variablesAdd(input.vectorX, tmp1);
      ifVariableCompare(input.vectorX, "<", tmp7, ()=>{variableSetToValue(input.vectorX, 255);variableSetToValue(input.vectorY, 99)}, ()=>{
        variableCopy(tmp7, input.vectorY);
        variablesAdd(input.vectorY, tmp2);
        variableCopy(tmp8, input.vectorX);
        variableSetToValue(tmp6, 1);
        ifVariableCompare(input.vectorY, "<", tmp7, ()=>{variablesAdd(input.vectorX, tmp6)}, []);
        ifVariableCompare(input.vectorX, "<", tmp8, ()=>{variableSetToValue(input.vectorX, 255);variableSetToValue(input.vectorY, 99)}, []);
      });
      break;
    case "sub":
      variableCopy(tmp7, input.vectorX);
      variablesSub(input.vectorX, tmp1);
      ifVariableCompare(input.vectorX, ">", tmp7, ()=>{variableSetToValue(input.vectorX, 0);variableSetToValue(input.vectorY, 0)}, ()=>{
        variableCopy(tmp7, input.vectorY);
        variablesSub(input.vectorY, tmp2);
        variableCopy(tmp8, input.vectorX);
        variableSetToValue(tmp6, 1);
        ifVariableCompare(input.vectorY, ">", tmp7, ()=>{variablesSub(input.vectorX, tmp6)}, []);
        ifVariableCompare(input.vectorX, ">", tmp8, ()=>{variableSetToValue(input.vectorX, 0);variableSetToValue(input.vectorY, 0)}, []);
      });
      break;
    case "set":
    default:
      variableCopy(input.vectorX, tmp1);
      variableCopy(input.vectorY, tmp2);
      break;
  }
};